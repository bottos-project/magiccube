#ifdef _GLFW_WAYLAND
	#include "glfw/src/wl_init.c"
#endif

