#if defined(_GLFW_X11) || defined(_GLFW_WAYLAND)
	#include "glfw/src/linux_joystick.c"
#endif

