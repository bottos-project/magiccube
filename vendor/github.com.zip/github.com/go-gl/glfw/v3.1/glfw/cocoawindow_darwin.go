package glfw

/*
#cgo CFLAGS: -x objective-c
#ifdef _GLFW_COCOA
	#include "glfw/src/cocoa_window.m"
#endif
*/
import "C"
